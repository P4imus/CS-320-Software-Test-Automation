/*Jeremiah Larrabee
 * CS-319
 * Module 3 Milestone
 * The purpose of this file is to test the contact service file
 */
package Contact;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ContactServiceTest {

  

  //This will test adding contacts
@Test
public void testAdd()
{
ContactService cs = new ContactService();
Contact test1 = new Contact("123456", "Mary", "AShley", "7153698759", "711 3rd St N");
assertEquals(true, cs.addContact(test1));
}


//This will test the removal of  contacts
@Test
public void testDelete()
{
 ContactService cs = new ContactService();
   
Contact test1 = new Contact("123456", "Mary", "AShley", "7153698759", "711 3rd St N");

cs.addContact(test1);

assertEquals(true, cs.deleteContact("123456"));

}



//This will test the removal of multiple contacts
@Test
public void testDeleteMult()
{
   ContactService cs = new ContactService();
     
Contact test1 = new Contact("123456", "Mary", "AShley", "7153698759", "711 3rd St N");
Contact test2 = new Contact("89645", "Draco", "Malfoy", "8953189756", "Hogwarts");
Contact test3 = new Contact("103697", "Harry", "Potter", "2369459875", "Cupboard Under the stairs");

cs.addContact(test1);
cs.addContact(test2);
cs.addContact(test3);

assertEquals(true, cs.deleteContact("123456"));
assertEquals(true, cs.deleteContact("89645"));
assertEquals(true, cs.deleteContact("103697"));
}



//Deletes a contact with the wrong ID
@Test
public void testDeletefail()
{
   ContactService cs = new ContactService();
     
Contact test1 = new Contact("123456", "Mary", "AShley", "7153698759", "711 3rd St N");


cs.addContact(test1);

assertEquals(false, cs.deleteContact("654321"));

}




//Tests adding duplicate IDs
@Test
public void testAddDuplicatID()
{
ContactService cs = new ContactService();
Contact test1 = new Contact("123456", "Mary", "AShley", "7153698759", "711 3rd St N");
Contact test2 = new Contact("123456", "Bob", "AShley", "7153698759", "711 3rd St N");

assertEquals(true, cs.addContact(test1));

assertEquals(false, cs.addContact(test2));
}


}
