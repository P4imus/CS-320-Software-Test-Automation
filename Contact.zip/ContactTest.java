/*Jeremiah Larrabee
 * CS-319
 * Module 3 Milestone
 * The purpose of this file is to test the contact file
 */

package Contact;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactTest {
	//A template for the tests
    Contact contact =  new Contact("103697", "Harry", "Potter", "2369459875", "Cupboard Under the stairs");

    @Test
    void getContactID() {
        assertEquals("103697", contact.getContactID());
    }
    
   

    @Test
    void getFirstName() {
        assertEquals("Harry", contact.getFirstName());
    }
    
   

    @Test
    void getLastName() {
        assertEquals("Potter", contact.getLastName());
    }

    @Test
    void getPhoneNumber() {
        assertEquals("2369459875", contact.getPhoneNumber());
    }

    @Test
    void getAddress() {
        assertEquals("Cupboard Under the stairs", contact.getAddress());
    }

    @Test
    void testToString() {
        assertEquals("Contact [contactID=103697, firstName=Harry, lastName=Potter, phoneNumber=2369459875, address=Cupboard Under the stairs]", contact.toString());
    }

}