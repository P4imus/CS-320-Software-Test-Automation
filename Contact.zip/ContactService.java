/*Jeremiah Larrabee
 * CS-319
 * Module 3 Milestone
 * The purpose of this file is to define the functions
 */


package Contact;


import java.util.HashMap;
import java.util.Map;





public class ContactService {

  //Where the contacts will be stored

  
private static ContactService reference = new ContactService();
private static Map<String, Contact> contacts;

ContactService() {
	 ContactService.contacts = new HashMap<String, Contact>();
 }
 
	
 public static ContactService getContact() {
	 return reference;
 }
  

 public boolean addContact(Contact contact) {
	 boolean isSuccess = false;
	 
	 if(!contacts.containsKey(contact.getContactID())) {
		 contacts.put(contact.getContactID(), contact);
		 isSuccess = true;
	 }
	 return isSuccess;
 }
  
//Will search for and delete a specific ID
 public boolean deleteContact(String contactID) {
		return contacts.remove(contactID) != null;
	}
		
public static Contact getContact(String contactID) {
		 return contacts.get(contactID);   
}
	
  // I removed the update function because the set functions can be used for it
}

